import React, { useEffect, useRef, useState } from 'react';
import { Megaphone } from 'lucide-react';
import { announcements } from '@/data/announcementData';

const AnnouncementTicker: React.FC = () => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [activeAnnouncements, setActiveAnnouncements] = useState(announcements.filter(a => a.active));

  useEffect(() => {
    // Filter only active announcements and sort by priority
    const filtered = announcements
      .filter(announcement => announcement.active)
      .sort((a, b) => a.priority - b.priority);
    
    setActiveAnnouncements(filtered);
  }, []);

  useEffect(() => {
    if (!scrollRef.current || activeAnnouncements.length === 0) return;

    const scrollElement = scrollRef.current;
    let animationId: number;
    let position = 0;

    const scroll = () => {
      if (isPaused) {
        animationId = requestAnimationFrame(scroll);
        return;
      }

      position -= 1;
      
      // Reset position when the entire content has scrolled
      if (Math.abs(position) >= scrollElement.scrollWidth / 2) {
        position = 0;
      }
      
      scrollElement.style.transform = `translateX(${position}px)`;
      animationId = requestAnimationFrame(scroll);
    };

    animationId = requestAnimationFrame(scroll);

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isPaused, activeAnnouncements]);

  // If no announcements, don't render the ticker
  if (activeAnnouncements.length === 0) return null;

  return (
    <div 
      className="bg-[#112240] text-white h-10 overflow-hidden flex items-center"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="flex-shrink-0 px-4 flex items-center border-r border-gray-600 h-full">
        <Megaphone size={18} className="mr-2" />
        <span className="text-xs font-bold tracking-wider">ANNOUNCEMENTS</span>
      </div>
      
      <div className="overflow-hidden relative flex-grow">
        <div 
          ref={scrollRef} 
          className="whitespace-nowrap inline-block"
          style={{ paddingLeft: '100%' }} // Start offscreen
        >
          {/* Duplicate announcements to create seamless loop */}
          {activeAnnouncements.map((announcement) => (
            <span key={announcement.id} className="px-6 text-sm">
              {announcement.text}
            </span>
          ))}
          {activeAnnouncements.map((announcement) => (
            <span key={`dup-${announcement.id}`} className="px-6 text-sm">
              {announcement.text}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AnnouncementTicker;
