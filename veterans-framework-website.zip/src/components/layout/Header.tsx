import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useIsMobile } from '@/hooks/use-mobile';
import { Menu, X, Settings } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';
import ShopCartIcon from '@/components/shop/ShopCartIcon';
import { useShop } from '@/components/shop/ShopContext';

interface NavLinkProps {
  href: string;
  children: React.ReactNode;
}

const NavLink: React.FC<NavLinkProps> = ({ href, children }) => (
  <Link 
    to={href} 
    className="text-gray-700 hover:text-blue-700 px-2 lg:px-3 py-2 rounded-md text-sm font-medium transition-colors whitespace-nowrap"
  >
    {children}
  </Link>
);

interface HeaderProps {
  onCartClick?: () => void;
}

const Header: React.FC<HeaderProps> = ({ onCartClick }) => {
  const isMobile = useIsMobile();
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const { cartItemCount } = useShop();

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50 w-full">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-14 sm:h-16 items-center">
          <div className="flex items-center min-w-0 flex-1">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <img 
                src="https://vlljavdgteoqvqkmdzvw.supabase.co/storage/v1/object/public/logos//VOS_vertical%20logo%201200x400png.png" 
                alt="Veterans Services Ohio" 
                className="h-10 sm:h-12 w-auto object-contain"
              />
            </Link>
          </div>
          
          <div className="flex items-center space-x-2">
            {isMobile ? (
              <>
                <Link to="/settings" className="p-2">
                  <Settings size={18} className="text-gray-700 hover:text-blue-700" />
                </Link>
                <ShopCartIcon itemCount={cartItemCount} onClick={onCartClick} />
                <button
                  onClick={toggleSidebar}
                  className="p-2 rounded-md text-gray-700 hover:text-blue-700 focus:outline-none"
                >
                  {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
                </button>
              </>
            ) : (
              <>
                <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
                  <NavLink href="/">Home</NavLink>
                  <NavLink href="/about">About</NavLink>
                  <NavLink href="/services">Services</NavLink>
                  <NavLink href="/events">Calendar</NavLink>
                  <NavLink href="/blog">Blog</NavLink>
                  <NavLink href="/shop">Shop</NavLink>
                  <NavLink href="/builds">Builds</NavLink>
                  <NavLink href="/contact">Contact</NavLink>
                  <Link to="/donate">
                    <Button variant="default" size="sm" className="bg-blue-700 hover:bg-blue-800 text-white ml-2">
                      Donate
                    </Button>
                  </Link>
                </nav>
                <div className="flex items-center space-x-2 ml-4">
                  <Link to="/settings">
                    <Settings size={18} className="text-gray-700 hover:text-blue-700" />
                  </Link>
                  <ShopCartIcon itemCount={cartItemCount} onClick={onCartClick} />
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;