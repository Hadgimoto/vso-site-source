import React from 'react';
import Header from './Header';
import Footer from './Footer';
import Sidebar from './Sidebar';
import { useAppContext } from '@/contexts/AppContext';
import { useIsMobile } from '@/hooks/use-mobile';
import { SEOData } from '@/types';
import { Helmet } from 'react-helmet-async';
import { ShopProvider } from '@/components/shop/ShopContext';

interface MainLayoutProps {
  children: React.ReactNode;
  seo?: SEOData;
  onCartClick?: () => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children, seo, onCartClick }) => {
  const { sidebarOpen } = useAppContext();
  const isMobile = useIsMobile();

  return (
    <ShopProvider>
      <div className="min-h-screen flex flex-col w-full overflow-x-hidden">
        {seo && (
          <Helmet>
            <title>{seo.title}</title>
            <meta name="description" content={seo.description} />
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
            {seo.canonical && <link rel="canonical" href={seo.canonical} />}
            {seo.openGraph && (
              <>
                <meta property="og:title" content={seo.openGraph.title || seo.title} />
                <meta property="og:description" content={seo.openGraph.description || seo.description} />
                {seo.openGraph.image && <meta property="og:image" content={seo.openGraph.image} />}
              </>
            )}
            {seo.twitterCard && (
              <>
                <meta name="twitter:card" content="summary_large_image" />
                <meta name="twitter:title" content={seo.twitterCard.title || seo.title} />
                <meta name="twitter:description" content={seo.twitterCard.description || seo.description} />
                {seo.twitterCard.image && <meta name="twitter:image" content={seo.twitterCard.image} />}
              </>
            )}
          </Helmet>
        )}

        <Header onCartClick={onCartClick} />

        <div className="flex-grow flex w-full">
          {isMobile && sidebarOpen && (
            <div className="fixed inset-0 z-40 lg:hidden">
              <div className="absolute inset-0 bg-gray-600 bg-opacity-75" onClick={() => {}} />
              <div className="relative flex-1 flex flex-col max-w-xs w-full bg-white">
                <Sidebar />
              </div>
            </div>
          )}

          <main className="flex-1 w-full">{children}</main>
        </div>

        <Footer />
      </div>
    </ShopProvider>
  );
};

export default MainLayout;