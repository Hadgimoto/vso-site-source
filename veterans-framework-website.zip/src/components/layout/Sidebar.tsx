import React from 'react';
import { Link } from 'react-router-dom';
import { Settings } from 'lucide-react';

const Sidebar: React.FC = () => {
  return (
    <div className="h-0 flex-1 flex flex-col overflow-y-auto pt-5 pb-4">
      <div className="flex-1 px-2 bg-white space-y-1">
        <Link
          to="/"
          className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        >
          Home
        </Link>

        <Link
          to="/about"
          className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        >
          About
        </Link>

        <Link
          to="/services"
          className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        >
          Services
        </Link>
        
        <Link
          to="/events"
          className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        >
          Events
        </Link>

        <Link
          to="/blog"
          className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        >
          Blog
        </Link>

        <Link
          to="/shop"
          className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        >
          Shop
        </Link>

        <Link
          to="/builds"
          className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        >
          Builds
        </Link>

        <Link
          to="/contact"
          className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        >
          Contact
        </Link>
        
        <Link
          to="/settings"
          className="group flex items-center px-2 py-2 text-base font-medium rounded-md text-gray-600 hover:bg-gray-50 hover:text-gray-900"
        >
          <Settings size={18} className="mr-2" />
          Settings
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;
