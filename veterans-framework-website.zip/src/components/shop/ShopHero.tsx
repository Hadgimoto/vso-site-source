import React from 'react';

interface ShopHeroProps {
  title: string;
  subtitle?: string;
}

const ShopHero: React.FC<ShopHeroProps> = ({ title, subtitle }) => {
  return (
    <section className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-3xl md:text-5xl font-extrabold mb-4 tracking-tight">
          {title}
        </h1>
        {subtitle && (
          <p className="text-lg md:text-xl max-w-3xl mx-auto text-blue-100">
            {subtitle}
          </p>
        )}
        <div className="mt-8 flex justify-center">
          <div className="inline-flex items-center px-6 py-3 border border-white rounded-md font-medium text-white bg-red-600 hover:bg-red-700 transition-colors">
            Every purchase directly supports veteran programs
          </div>
        </div>
      </div>
    </section>
  );
};

export default ShopHero;
