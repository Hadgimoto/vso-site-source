import React from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Product } from '@/types';

interface ProductCardProps {
  product: {
    id: string;
    name: string;
    description: string;
    price: number;
    image: string;
    category: string;
    sizes?: string[];
  };
  onAddToCart: (productId: string, size?: string) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart }) => {
  const [selectedSize, setSelectedSize] = React.useState<string | undefined>(
    product.sizes?.[0]
  );
  const [imageError, setImageError] = React.useState(false);
  const [imageKey, setImageKey] = React.useState(Date.now());

  const handleImageError = () => {
    setImageError(true);
  };

  const handleImageLoad = () => {
    setImageError(false);
  };

  const refreshImage = () => {
    setImageKey(Date.now());
    setImageError(false);
  };

  const imageUrl = imageError 
    ? 'https://placehold.co/400x300/gray/white?text=Image+Not+Available'
    : `${product.image}&refresh=${imageKey}`;

  return (
    <Card className="h-full flex flex-col overflow-hidden transition-all duration-200 hover:shadow-md">
      <div className="h-48 overflow-hidden bg-gray-100 relative">
        <img 
          src={imageUrl}
          alt={product.name}
          className="w-full h-full object-cover"
          onError={handleImageError}
          onLoad={handleImageLoad}
          key={imageKey}
        />
        <Badge className="absolute top-2 right-2 bg-red-600">
          {product.category}
        </Badge>
        {imageError && (
          <Button 
            size="sm" 
            className="absolute bottom-2 right-2 text-xs"
            onClick={refreshImage}
          >
            Refresh
          </Button>
        )}
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">{product.name}</CardTitle>
      </CardHeader>
      <CardContent className="pb-2 flex-grow">
        <p className="text-xl font-bold text-blue-700">${product.price.toFixed(2)}</p>
        <p className="mt-2 text-sm text-gray-600">{product.description}</p>
        
        {product.sizes && product.sizes.length > 0 && (
          <div className="mt-3">
            <p className="text-sm font-medium mb-1">Size:</p>
            <div className="flex flex-wrap gap-1">
              {product.sizes.map((size) => (
                <Button 
                  key={size}
                  variant={selectedSize === size ? "default" : "outline"}
                  size="sm"
                  className={`min-w-[40px] ${selectedSize === size ? 'bg-blue-700' : ''}`}
                  onClick={() => setSelectedSize(size)}
                >
                  {size}
                </Button>
              ))}
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button 
          className="w-full bg-blue-700 hover:bg-blue-800"
          onClick={() => onAddToCart(product.id, selectedSize)}
        >
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;