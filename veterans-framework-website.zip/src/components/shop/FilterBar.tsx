import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface FilterBarProps {
  categories: string[];
  sizes: string[];
  onFilterChange: (filters: {
    category?: string;
    size?: string;
    sort?: string;
    search?: string;
  }) => void;
}

const FilterBar: React.FC<FilterBarProps> = ({ 
  categories, 
  sizes, 
  onFilterChange 
}) => {
  const [category, setCategory] = React.useState<string>('');
  const [size, setSize] = React.useState<string>('');
  const [sort, setSort] = React.useState<string>('newest');
  const [search, setSearch] = React.useState<string>('');

  const handleFilterChange = (key: string, value: string) => {
    switch (key) {
      case 'category':
        setCategory(value);
        break;
      case 'size':
        setSize(value);
        break;
      case 'sort':
        setSort(value);
        break;
      case 'search':
        setSearch(value);
        break;
    }

    onFilterChange({
      category: key === 'category' ? value : category,
      size: key === 'size' ? value : size,
      sort: key === 'sort' ? value : sort,
      search: key === 'search' ? value : search
    });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFilterChange({ category, size, sort, search });
  };

  const handleReset = () => {
    setCategory('');
    setSize('');
    setSort('newest');
    setSearch('');
    onFilterChange({});
  };

  return (
    <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
      <form onSubmit={handleSearchSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <form className="flex w-full items-center space-x-2" onSubmit={handleSearchSubmit}>
              <Input
                type="text"
                placeholder="Search products..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full"
              />
              <Button type="submit" size="sm">Search</Button>
            </form>
          </div>
          
          <div>
            <Select value={category} onValueChange={(value) => handleFilterChange('category', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-categories">All Categories</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Select value={size} onValueChange={(value) => handleFilterChange('size', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Size" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all-sizes">All Sizes</SelectItem>
                {sizes.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Select value={sort} onValueChange={(value) => handleFilterChange('sort', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Sort By" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="price-asc">Price: Low to High</SelectItem>
                <SelectItem value="price-desc">Price: High to Low</SelectItem>
                <SelectItem value="name-asc">Name: A to Z</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex justify-end">
          <Button 
            type="button" 
            variant="outline" 
            onClick={handleReset}
            size="sm"
          >
            Reset Filters
          </Button>
        </div>
      </form>
    </div>
  );
};

export default FilterBar;
