// This file is no longer needed - functionality moved to HeroSection
// Keeping as placeholder to prevent import errors during transition