import React, { useState } from 'react';
import { Event } from '@/data/eventData';
import CalendarViews from './CalendarViews';
import MonthCalendarView from './MonthCalendarView';
import EventList from './EventList';

interface CalendarDisplayProps {
  events: Event[];
}

const CalendarDisplay: React.FC<CalendarDisplayProps> = ({ events }) => {
  const [view, setView] = useState('month');
  const [category, setCategory] = useState('all');
  const [currentMonth] = useState(new Date());

  // Filter events by category if needed
  const filteredEvents = category === 'all' ? events : events.filter(event => 
    event.category?.toLowerCase() === category.toLowerCase()
  );

  const handleViewChange = (newView: string) => {
    setView(newView);
  };

  const handleCategoryChange = (newCategory: string) => {
    setCategory(newCategory);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <CalendarViews
        events={events}
        selectedView={view}
        onViewChange={handleViewChange}
        selectedCategory={category}
        onCategoryChange={handleCategoryChange}
      />

      {view === 'month' && (
        <MonthCalendarView 
          events={filteredEvents} 
          currentMonth={currentMonth} 
        />
      )}
      {view === 'week' && <div className="p-4 text-center">Week view coming soon</div>}
      {view === 'list' && <EventList events={filteredEvents} />}
    </div>
  );
};

export default CalendarDisplay;
