import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, MapPin, Clock, ArrowRight } from '@phosphor-icons/react';
import { Event } from '@/data/eventData';

interface EventCardProps {
  event: Event;
}

const EventCard: React.FC<EventCardProps> = ({ event }) => {
  // Format date for display
  const formatDate = (dateString: string) => {
    const options: Intl.DateTimeFormatOptions = { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  return (
    <Card className="h-full flex flex-col hover:shadow-md transition-shadow duration-200 mb-8 border border-gray-200">
      <CardHeader className="pb-3 pt-6 px-6">
        <CardTitle className="text-xl text-blue-700 mb-2">{event.title}</CardTitle>
        <div className="flex items-center text-gray-500 text-sm mt-2">
          <Calendar size={16} weight="regular" className="mr-2" />
          <span>{formatDate(event.date)}</span>
        </div>
      </CardHeader>
      <CardContent className="flex-grow px-6 pb-4">
        <CardDescription className="text-gray-600 mb-6 text-base leading-relaxed">
          {event.description}
        </CardDescription>
        <div className="flex items-center text-gray-500 text-sm mb-3">
          <MapPin size={16} weight="regular" className="mr-2" />
          <span>{event.location}</span>
        </div>
        <div className="flex items-center text-gray-500 text-sm">
          <Clock size={16} weight="regular" className="mr-2" />
          <span>{event.time}</span>
        </div>
      </CardContent>
      <CardFooter className="px-6 pb-6 pt-2">
        <button className="text-blue-700 hover:text-blue-900 text-sm font-medium flex items-center">
          Learn More
          <ArrowRight size={16} weight="bold" className="ml-1" />
        </button>
      </CardFooter>
    </Card>
  );
};

export default EventCard;
