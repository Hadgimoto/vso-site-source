import React, { useState } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { Event } from '@/data/eventData';
import { CalendarBlank, CircleDashed } from '@phosphor-icons/react';

interface EventCalendarProps {
  events: Event[];
  onDateSelect: (date: Date | undefined) => void;
}

const EventCalendar: React.FC<EventCalendarProps> = ({ events, onDateSelect }) => {
  const [date, setDate] = useState<Date | undefined>(new Date());

  // Create a map of dates that have events
  const eventDates = events.reduce((acc, event) => {
    const eventDate = new Date(event.date);
    const dateString = eventDate.toISOString().split('T')[0];
    acc[dateString] = true;
    return acc;
  }, {} as Record<string, boolean>);

  // Handle date change
  const handleSelect = (selectedDate: Date | undefined) => {
    setDate(selectedDate);
    onDateSelect(selectedDate);
  };

  // Function to add custom CSS classes to days with events
  const getDayClassNames = (day: Date): string => {
    const dateString = day.toISOString().split('T')[0];
    return eventDates[dateString] ? 'bg-blue-100 text-blue-800 font-semibold rounded-full' : '';
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <h2 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
        <CalendarBlank size={20} weight="fill" className="mr-2 text-blue-600" />
        Event Calendar
      </h2>
      <Calendar
        mode="single"
        selected={date}
        onSelect={handleSelect}
        className="rounded-md border"
        modifiersClassNames={{
          selected: 'bg-blue-600 text-white hover:bg-blue-600 hover:text-white',
          today: 'bg-gray-100 text-gray-900 font-medium'
        }}
        modifiersStyles={{
          selected: { fontWeight: 'bold' }
        }}
        components={{
          DayContent: ({ date, activeModifiers }) => {
            // Only customize if not already selected or today
            if (!activeModifiers.selected && !activeModifiers.today) {
              const customClass = getDayClassNames(date);
              if (customClass) {
                return (
                  <div className={customClass}>
                    {date.getDate()}
                  </div>
                );
              }
            }
            return date.getDate();
          }
        }}
      />
      <div className="mt-6 text-sm text-gray-600">
        <div className="flex items-center mb-2">
          <div className="w-4 h-4 rounded-full bg-blue-100 border border-blue-200 mr-2"></div>
          <span>Event scheduled</span>
        </div>
        <div className="flex items-center">
          <div className="w-4 h-4 rounded-full bg-blue-600 mr-2"></div>
          <span>Selected date</span>
        </div>
      </div>
    </div>
  );
};

export default EventCalendar;
