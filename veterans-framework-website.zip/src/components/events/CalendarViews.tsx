import React from 'react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Event } from '@/data/eventData';
import { CaretLeft, CaretRight, Calendar } from '@phosphor-icons/react';

interface CalendarViewsProps {
  events: Event[];
  selectedView: string;
  onViewChange: (view: string) => void;
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

const categories = [
  { id: 'all', label: 'All' },
  { id: 'community', label: 'Community' },
  { id: 'veterans', label: 'Veterans' },
  { id: 'fundraiser', label: 'Fundraiser' },
  { id: 'education', label: 'Education' },
  { id: 'sports', label: 'Sports' },
  { id: 'arts', label: 'Arts' },
  { id: 'health', label: 'Health' },
  { id: 'business', label: 'Business' },
];

const CalendarViews: React.FC<CalendarViewsProps> = ({
  selectedView,
  onViewChange,
  selectedCategory,
  onCategoryChange,
}) => {
  return (
    <div className="mb-6">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4">
        <h2 className="text-2xl font-bold mb-4 sm:mb-0">Community Calendar</h2>
        <div className="flex space-x-2">
          <button
            className="text-sm px-3 py-1.5 rounded-md border border-gray-200 hover:bg-gray-50 flex items-center"
          >
            <Calendar size={16} weight="regular" className="mr-1.5" />
            Today
          </button>
          <button
            className="text-sm p-1.5 rounded-md border border-gray-200 hover:bg-gray-50 flex items-center justify-center w-9 h-9"
          >
            <CaretLeft size={18} weight="bold" />
          </button>
          <button
            className="text-sm p-1.5 rounded-md border border-gray-200 hover:bg-gray-50 flex items-center justify-center w-9 h-9"
          >
            <CaretRight size={18} weight="bold" />
          </button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <div className="flex overflow-x-auto pb-2 no-scrollbar">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => onCategoryChange(category.id)}
              className={`px-4 py-2 text-sm rounded-full mr-2 whitespace-nowrap transition-colors ${selectedCategory === category.id
                ? 'bg-blue-600 text-white font-medium'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
            >
              {category.label}
            </button>
          ))}
        </div>

        <div className="flex">
          <Tabs defaultValue={selectedView} onValueChange={onViewChange} className="w-[250px]">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="month">Month</TabsTrigger>
              <TabsTrigger value="week">Week</TabsTrigger>
              <TabsTrigger value="list">List</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default CalendarViews;
