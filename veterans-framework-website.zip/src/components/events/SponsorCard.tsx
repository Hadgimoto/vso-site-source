import React from 'react';
import { Card, CardFooter } from '@/components/ui/card';
import { Calendar, Clock, Lightning } from '@phosphor-icons/react';

interface SponsorCardProps {
  sponsor: string;
  title: string;
  description: string;
  date: string;
  time: string;
  logo?: string;
}

const SponsorCard: React.FC<SponsorCardProps> = ({
  sponsor,
  title,
  description,
  date,
  time,
  logo
}) => {
  const formattedDate = new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'numeric',
    day: 'numeric',
  });

  return (
    <Card className="h-full flex flex-col border border-gray-200 rounded-md overflow-hidden shadow-sm">
      <div className="p-4 bg-gray-50 text-xs text-gray-600 font-medium">
        Sponsored by {sponsor}
      </div>
      <div className="flex items-start p-4 flex-grow">
        <div className="mr-4">
          <div className="w-12 h-12 bg-gray-100 rounded-md flex items-center justify-center">
            {logo ? (
              <img src={logo} alt={sponsor} className="w-8 h-8" />
            ) : (
              <Lightning size={24} weight="bold" className="text-gray-500" />
            )}
          </div>
        </div>
        <div>
          <h3 className="font-semibold text-lg leading-tight">{title}</h3>
          <p className="text-sm text-gray-600 mt-2 leading-snug">{description}</p>
        </div>
      </div>
      <CardFooter className="border-t p-4 bg-white">
        <div className="flex justify-between w-full text-xs text-gray-500 whitespace-nowrap">
          <div className="flex items-center">
            <Calendar size={14} weight="regular" className="mr-1" />
            <span>{formattedDate}</span>
          </div>
          <div className="flex items-center">
            <Clock size={14} weight="regular" className="mr-1" />
            <span>{time}</span>
          </div>
        </div>
      </CardFooter>
    </Card>
  );
};

export default SponsorCard;
