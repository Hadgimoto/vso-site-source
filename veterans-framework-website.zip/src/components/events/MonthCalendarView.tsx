import React from 'react';
import { Event } from '@/data/eventData';
import { DotsThree } from '@phosphor-icons/react';

interface MonthCalendarViewProps {
  events: Event[];
  currentMonth?: Date;
}

const MonthCalendarView: React.FC<MonthCalendarViewProps> = ({ events, currentMonth = new Date() }) => {
  // Get days in month
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  // Get day of week for first day of month (0 = Sunday, 6 = Saturday)
  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();
  const daysInMonth = getDaysInMonth(year, month);
  const firstDayOfMonth = getFirstDayOfMonth(year, month);
  
  // Get days from previous month to fill the first week
  const prevMonthDays = firstDayOfMonth;
  
  // Calculate total cells needed (previous month days + current month days)
  const totalCells = Math.ceil((prevMonthDays + daysInMonth) / 7) * 7;
  
  // Get days for next month to fill the last week
  const nextMonthDays = totalCells - (prevMonthDays + daysInMonth);

  // Create array of day numbers for the calendar
  const calendarDays = [];
  
  // Add previous month days
  const prevMonthLastDay = getDaysInMonth(year, month - 1);
  for (let i = 0; i < prevMonthDays; i++) {
    calendarDays.push({
      day: prevMonthLastDay - prevMonthDays + i + 1,
      currentMonth: false,
      date: new Date(year, month - 1, prevMonthLastDay - prevMonthDays + i + 1)
    });
  }
  
  // Add current month days
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push({
      day: i,
      currentMonth: true,
      date: new Date(year, month, i)
    });
  }
  
  // Add next month days
  for (let i = 1; i <= nextMonthDays; i++) {
    calendarDays.push({
      day: i,
      currentMonth: false,
      date: new Date(year, month + 1, i)
    });
  }

  // Group days into weeks
  const weeks = [];
  for (let i = 0; i < calendarDays.length; i += 7) {
    weeks.push(calendarDays.slice(i, i + 7));
  }

  const weekdays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  // Check if today
  const isToday = (date: Date) => {
    const today = new Date();
    return date.getDate() === today.getDate() &&
      date.getMonth() === today.getMonth() &&
      date.getFullYear() === today.getFullYear();
  };

  return (
    <div className="bg-white rounded-lg overflow-hidden border border-gray-200 shadow-sm">
      <div className="grid grid-cols-7">
        {weekdays.map((day) => (
          <div key={day} className="py-2 text-center text-sm font-medium text-gray-700 bg-gray-50">
            {day}
          </div>
        ))}
        
        {weeks.map((week, weekIndex) => (
          <React.Fragment key={`week-${weekIndex}`}>
            {week.map((day, dayIndex) => {
              const dateStr = day.date.toISOString().split('T')[0];
              const dayEvents = events.filter(event => {
                const eventDate = new Date(event.date).toISOString().split('T')[0];
                return eventDate === dateStr;
              });
              
              const today = isToday(day.date);
              
              return (
                <div 
                  key={`day-${weekIndex}-${dayIndex}`}
                  className={`min-h-[100px] p-2 ${weekIndex > 0 ? 'border-t' : ''} ${dayIndex > 0 ? 'border-l' : ''} border-gray-200 
                    ${!day.currentMonth ? 'bg-gray-50 text-gray-400' : 'bg-white'}
                    ${today ? 'ring-2 ring-inset ring-blue-500' : ''}`}
                >
                  <div className="text-right mb-1">
                    <span className={`inline-flex items-center justify-center text-sm 
                      ${today ? 'bg-blue-500 text-white w-6 h-6 rounded-full' : ''}
                      ${day.currentMonth ? 'font-medium' : 'text-gray-400'}`}>
                      {day.day}
                    </span>
                  </div>
                  <div className="space-y-1">
                    {dayEvents.slice(0, 2).map((event) => (
                      <div 
                        key={event.id} 
                        className="text-xs p-1.5 bg-blue-100 text-blue-800 rounded truncate border border-blue-200"
                      >
                        {event.title}
                      </div>
                    ))}
                    {dayEvents.length > 2 && (
                      <div className="text-xs text-gray-500 pl-1 flex items-center">
                        <DotsThree size={16} weight="bold" className="inline mr-0.5" />
                        <span>{dayEvents.length - 2} more</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default MonthCalendarView;
