import React, { useEffect, useState, useRef } from 'react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import SponsorCard from './SponsorCard';
import { supabase } from '@/lib/supabase';
import { Trophy } from '@phosphor-icons/react';

interface Sponsor {
  id: number;
  sponsor: string;
  title: string;
  description: string;
  date: string;
  time: string;
  logo?: string;
  featured?: boolean;
}

// Fallback sponsor data if API fails
const fallbackSponsors: Sponsor[] = [
  {
    id: 1,
    sponsor: 'Veterans Support Alliance',
    title: "Veteran's Appreciation Day",
    description: 'Help us honor those who served. Join the celebration.',
    date: '2023-10-20',
    time: '06:00 PM - 09:00 PM',
    featured: true
  },
  {
    id: 2,
    sponsor: 'Education First Foundation',
    title: 'Fundraiser for Local Schools',
    description: 'Invest in our children\'s future. Every dollar counts.',
    date: '2023-10-24',
    time: '05:30 PM - 08:30 PM',
    featured: true
  },
  {
    id: 3,
    sponsor: 'Tech for All',
    title: 'Tech Workshop for Seniors',
    description: 'Bridging the digital divide for seniors in our community.',
    date: '2023-10-17',
    time: '10:00 AM - 12:00 PM',
    featured: true
  },
  {
    id: 4,
    sponsor: 'Wellness Partners',
    title: 'Annual Health Fair',
    description: 'Your health is our priority. Join us for free screenings.',
    date: '2023-11-01',
    time: '09:00 AM - 03:00 PM',
    featured: true
  },
  {
    id: 5,
    sponsor: 'Local Business Association',
    title: 'Small Business Saturday',
    description: 'Shop small, support local. Discover unique products and services.',
    date: '2023-11-25',
    time: '10:00 AM - 06:00 PM',
    featured: true
  },
  {
    id: 6,
    sponsor: 'Military Family Network',
    title: 'Military Family Appreciation Event',
    description: 'Supporting the families behind our service members.',
    date: '2023-11-14',
    time: '11:00 AM - 03:00 PM',
    featured: true
  },
];

const FeaturedSponsors: React.FC = () => {
  const [sponsors, setSponsors] = useState<Sponsor[]>(fallbackSponsors);
  const [loading, setLoading] = useState(true);
  const [api, setApi] = useState<any>(null);

  useEffect(() => {
    const fetchSponsors = async () => {
      try {
        // Attempt to fetch sponsors from Supabase
        const { data, error } = await supabase
          .from('sponsors')
          .select('*')
          .eq('featured', true);

        if (error) {
          console.error('Error fetching sponsors:', error);
          // Use fallback data on error
          return;
        }

        if (data && data.length > 0) {
          setSponsors(data);
        }
      } catch (err) {
        console.error('Failed to load sponsors:', err);
        // Fallback to sample data on error
      } finally {
        setLoading(false);
      }
    };

    fetchSponsors();
  }, []);

  // Set up auto-scrolling with the carousel API
  useEffect(() => {
    if (!api) return;

    // Auto-scroll every 5 seconds
    const autoplayInterval = setInterval(() => {
      api.scrollNext();
    }, 5000);

    // Clean up interval on unmount
    return () => clearInterval(autoplayInterval);
  }, [api]);

  if (loading) {
    return <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">Loading sponsors...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
      <div className="flex items-center mb-6">
        <Trophy size={24} weight="fill" className="text-amber-500 mr-2" />
        <h2 className="text-2xl font-bold">Featured Sponsors</h2>
      </div>
      <Carousel
        opts={{
          align: 'start',
          loop: true,
        }}
        setApi={setApi}
        className="w-full relative"
      >
        <CarouselContent className="-ml-4">
          {sponsors.map((sponsor) => (
            <CarouselItem key={sponsor.id} className="pl-4 md:basis-1/2 lg:basis-1/4">
              <div className="p-1 h-full"> {/* Added h-full to ensure uniform height */}
                <SponsorCard
                  sponsor={sponsor.sponsor}
                  title={sponsor.title}
                  description={sponsor.description}
                  date={sponsor.date}
                  time={sponsor.time}
                  logo={sponsor.logo}
                />
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious className="-left-4 sm:-left-6 bg-white border border-gray-200" />
        <CarouselNext className="-right-4 sm:-right-6 bg-white border border-gray-200" />
      </Carousel>
    </div>
  );
};

export default FeaturedSponsors;
