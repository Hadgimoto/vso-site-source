import React from 'react';
import EventCard from './EventCard';
import { Event } from '@/data/eventData';

interface EventListProps {
  events: Event[];
  selectedDate?: Date;
}

const EventList: React.FC<EventListProps> = ({ events, selectedDate }) => {
  // Filter events by selected date if provided
  const filteredEvents = selectedDate 
    ? events.filter(event => {
        const eventDate = new Date(event.date);
        return eventDate.toDateString() === selectedDate.toDateString();
      })
    : events;

  if (filteredEvents.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 text-lg">
          {selectedDate 
            ? 'No events scheduled for the selected date.' 
            : 'No upcoming events at this time.'}
        </p>
        {selectedDate && (
          <button 
            className="mt-6 text-blue-700 hover:text-blue-900 font-medium"
            onClick={() => window.location.reload()}
          >
            View all events
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 px-8 py-8">
      {filteredEvents.map(event => (
        <EventCard key={event.id} event={event} />
      ))}
    </div>
  );
};

export default EventList;
