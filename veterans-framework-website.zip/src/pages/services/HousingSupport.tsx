import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const HousingSupport: React.FC = () => {
  const seoData = {
    title: 'Housing Support - Veterans Services Ohio',
    description: 'Housing assistance and support services for Ohio veterans, including emergency housing, rental assistance, and home ownership programs.',
    openGraph: {
      image: 'https://veteransservicesohio.org/images/housing-hero.jpg'
    }
  };

  return (
    <MainLayout seo={seoData}>
      {/* Hero Section */}
      <section className="bg-blue-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Housing Support</h1>
            <p className="text-xl mb-8">{{housing_hero_description}}</p>
            <Button size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
              Apply for Assistance
            </Button>
          </div>
        </div>
      </section>

      {/* Programs Overview */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Our Housing Programs</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Emergency Housing</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{emergency_housing_description}}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Rental Assistance</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{rental_assistance_description}}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Home Ownership</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{home_ownership_description}}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Eligibility */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-8">Eligibility Requirements</h2>
            <div className="prose max-w-none">
              <p>{{housing_eligibility_description}}</p>
              <ul>
                <li>{{eligibility_requirement_1}}</li>
                <li>{{eligibility_requirement_2}}</li>
                <li>{{eligibility_requirement_3}}</li>
                <li>{{eligibility_requirement_4}}</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Application Process */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Application Process</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="w-16 h-16 bg-blue-700 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">1</div>
              <h3 className="text-xl font-bold mb-2">Submit Application</h3>
              <p>{{application_step_1}}</p>
            </div>
            <div>
              <div className="w-16 h-16 bg-blue-700 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">2</div>
              <h3 className="text-xl font-bold mb-2">Verification</h3>
              <p>{{application_step_2}}</p>
            </div>
            <div>
              <div className="w-16 h-16 bg-blue-700 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-4">3</div>
              <h3 className="text-xl font-bold mb-2">Approval & Support</h3>
              <p>{{application_step_3}}</p>
            </div>
          </div>
          <div className="mt-12 text-center">
            <Button size="lg">Start Application</Button>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default HousingSupport;