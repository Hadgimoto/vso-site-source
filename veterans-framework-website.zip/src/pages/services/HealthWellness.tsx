import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const HealthWellness: React.FC = () => {
  const seoData = {
    title: 'Health & Wellness - Veterans Services Ohio',
    description: 'Health and wellness programs for Ohio veterans, including mental health services, physical wellness, and healthcare navigation assistance.',
    openGraph: {
      image: 'https://veteransservicesohio.org/images/health-hero.jpg'
    }
  };

  return (
    <MainLayout seo={seoData}>
      {/* Hero Section */}
      <section className="bg-blue-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Health & Wellness</h1>
            <p className="text-xl mb-8">{{health_hero_description}}</p>
            <Button size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
              Find Resources
            </Button>
          </div>
        </div>
      </section>

      {/* Programs Overview */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Our Health & Wellness Programs</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Mental Health Services</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{mental_health_description}}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Physical Wellness</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{physical_wellness_description}}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Healthcare Navigation</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{healthcare_navigation_description}}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Resources */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Resources</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Crisis Support</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">{{crisis_support_description}}</p>
                <div className="bg-blue-50 p-4 rounded-md border border-blue-200">
                  <p className="font-bold mb-2">24/7 Crisis Line:</p>
                  <p className="text-xl font-bold">{{crisis_phone_number}}</p>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Support Groups</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="mb-4">{{support_groups_description}}</p>
                <Button variant="outline" className="w-full">Find a Group</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Healthcare Partners */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Our Healthcare Partners</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {/* Partner logos placeholders */}
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{healthcare_partner_logo}}</p>
            </div>
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{healthcare_partner_logo}}</p>
            </div>
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{healthcare_partner_logo}}</p>
            </div>
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{healthcare_partner_logo}}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Wellness Events */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Upcoming Wellness Events</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>{{event_title}}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold mb-2">Date: {{event_date}}</p>
                <p className="mb-4">Location: {{event_location}}</p>
                <p>{{event_description}}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>{{event_title}}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold mb-2">Date: {{event_date}}</p>
                <p className="mb-4">Location: {{event_location}}</p>
                <p>{{event_description}}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>{{event_title}}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold mb-2">Date: {{event_date}}</p>
                <p className="mb-4">Location: {{event_location}}</p>
                <p>{{event_description}}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default HealthWellness;