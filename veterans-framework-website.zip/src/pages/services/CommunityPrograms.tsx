import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const CommunityPrograms: React.FC = () => {
  const seoData = {
    title: 'Community Programs - Veterans Services Ohio',
    description: 'Community programs and events for Ohio veterans and their families, fostering connection, support, and engagement.',
    openGraph: {
      image: 'https://veteransservicesohio.org/images/community-hero.jpg'
    }
  };

  return (
    <MainLayout seo={seoData}>
      {/* Hero Section */}
      <section className="bg-blue-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Community Programs</h1>
            <p className="text-xl mb-8">{{community_hero_description}}</p>
            <Button size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
              Join a Program
            </Button>
          </div>
        </div>
      </section>

      {/* Programs Overview */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Our Community Programs</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Veteran Social Events</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{social_events_description}}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Family Support Groups</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{family_support_description}}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Volunteer Opportunities</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{volunteer_opportunities_description}}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Upcoming Events</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>{{event_title}}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold mb-2">Date: {{event_date}}</p>
                <p className="mb-2">Time: {{event_time}}</p>
                <p className="mb-4">Location: {{event_location}}</p>
                <p className="mb-6">{{event_description}}</p>
                <Button variant="outline">Register</Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>{{event_title}}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="font-semibold mb-2">Date: {{event_date}}</p>
                <p className="mb-2">Time: {{event_time}}</p>
                <p className="mb-4">Location: {{event_location}}</p>
                <p className="mb-6">{{event_description}}</p>
                <Button variant="outline">Register</Button>
              </CardContent>
            </Card>
          </div>
          <div className="mt-8 text-center">
            <Button variant="outline">View All Events</Button>
          </div>
        </div>
      </section>

      {/* Community Partners */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Community Partners</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {/* Partner logos placeholders */}
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{community_partner_logo}}</p>
            </div>
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{community_partner_logo}}</p>
            </div>
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{community_partner_logo}}</p>
            </div>
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{community_partner_logo}}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Community Impact</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <p className="italic mb-4">"{{community_testimonial_1}}"</p>
              <p className="font-semibold">- {{testimonial_name_1}}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <p className="italic mb-4">"{{community_testimonial_2}}"</p>
              <p className="font-semibold">- {{testimonial_name_2}}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <p className="italic mb-4">"{{community_testimonial_3}}"</p>
              <p className="font-semibold">- {{testimonial_name_3}}</p>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
};

export default CommunityPrograms;