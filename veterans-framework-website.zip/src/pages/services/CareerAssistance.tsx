import React from 'react';
import MainLayout from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const CareerAssistance: React.FC = () => {
  const seoData = {
    title: 'Career Assistance - Veterans Services Ohio',
    description: 'Career services and job training for Ohio veterans, including resume building, job placement, and skills development.',
    openGraph: {
      image: 'https://veteransservicesohio.org/images/career-hero.jpg'
    }
  };

  return (
    <MainLayout seo={seoData}>
      {/* Hero Section */}
      <section className="bg-blue-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Career Assistance</h1>
            <p className="text-xl mb-8">{{career_hero_description}}</p>
            <Button size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
              Schedule Consultation
            </Button>
          </div>
        </div>
      </section>

      {/* Programs Overview */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Career Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <CardTitle>Resume Building</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{resume_building_description}}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Job Placement</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{job_placement_description}}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Skills Training</CardTitle>
              </CardHeader>
              <CardContent>
                <p>{{skills_training_description}}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Employer Partners */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Our Employer Partners</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {/* Partner logos placeholders */}
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{partner_logo}}</p>
            </div>
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{partner_logo}}</p>
            </div>
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{partner_logo}}</p>
            </div>
            <div className="h-24 bg-white rounded-lg shadow-sm flex items-center justify-center">
              <p className="text-gray-400">{{partner_logo}}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Success Stories */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <p className="italic mb-4">"{{career_success_story_1}}"</p>
              <p className="font-semibold">- {{success_story_name_1}}, {{success_story_job_1}}</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <p className="italic mb-4">"{{career_success_story_2}}"</p>
              <p className="font-semibold">- {{success_story_name_2}}, {{success_story_job_2}}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Get Started */}
      <section className="py-16 bg-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Your Career Journey?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">{{career_cta_description}}</p>
          <Button size="lg" className="bg-white text-blue-700 hover:bg-gray-100">
            Schedule an Appointment
          </Button>
        </div>
      </section>
    </MainLayout>
  );
};

export default CareerAssistance;